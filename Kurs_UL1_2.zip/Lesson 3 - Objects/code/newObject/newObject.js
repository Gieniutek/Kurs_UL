(function (global) {
	if (!global.UAM) {
		global.UAM = {};
	}

	function newObject(construct, arg) {
       // Object.getPrototypeOf(construct);
        construct.call(arg);
    }

	global.UAM.newObject = newObject;
}(window));

/*
	Zaimplementuj funkcję newObject, która będzie działać analogicznie do operatora new. Pierwszym parametrem funkcji niech będzie
	konstruktor, natomiast pozostałe to parametry konstruktora. Przykładowe zastosowanie:

	new MyClass(arg1, arg2) -> newObject(MyClass, arg1, arg2)
*/


